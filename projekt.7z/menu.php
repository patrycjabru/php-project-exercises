<!DOCTYPE html>
<?php
echo "MENU:";
echo <<<HTML
            <br/>
HTML;
echo <<<HTML
            <a href="CreateNewBlog.html">Utwórz nowy blog</a></br>
HTML;
echo <<<HTML
            <a href="blog.php">Lista blogów</a><br/><br/>
HTML;
?>